<!-- <!DOCTYPE html>
<html>
<head>
    <title><?php echo e($data['subject']); ?></title>
</head>
<body>
    <h3>Hello, <?php echo e($data['name']); ?></h3>
    <p><?php echo e($data['message']); ?></p>
    <p>Thank you for using our service.</p>
</body>
</html> -->



<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($data['subject']); ?></title>
    <style>
        /* Disable text selection and context menu */
        body {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            margin: 20px;
            font-family: Arial, sans-serif;
        }

        a {
            pointer-events: auto;
            text-decoration: none;
        }

        .btn-link {
            padding: 10px 20px;
            background-color: #28a745;
            color: #fff !important;
            border-radius: 5px;
            display: inline-block;
            cursor: pointer;
        }
    </style>
    <script>
        // Disable right-click
        document.addEventListener('contextmenu', e => e.preventDefault());

        // Disable common keyboard shortcuts (Ctrl+C, Ctrl+U, etc.)
        document.addEventListener('keydown', function(e) {
            if (e.ctrlKey && ['c', 'u', 's', 'a'].includes(e.key.toLowerCase())) {
                e.preventDefault();
            }
        });
        document.addEventListener('contextmenu', event => event.preventDefault());
        document.addEventListener('copy', event => event.preventDefault());
    </script>
</head>
<body oncopy="return false" oncut="return false" onpaste="return false">
    <h3>Dear <?php echo e($data['name']); ?>,</h3>
    <p>You have been added as an agent on ATai Chatbot. Please verify your email to complete the registration.</p>
    <p>Click the button below to verify your email:</p>
    <p>
        <a href="<?php echo e($data['verification_link']); ?>" class="btn-link">Verify Email</a>
    </p>
    <br>
    <p>Best regards,<br>[Admin Name]</p>
</body>
</html>
<?php /**PATH D:\abdul doc\coding\laravel_php\atai-laravel-api-main\resources\views/emails/sendMail.blade.php ENDPATH**/ ?>