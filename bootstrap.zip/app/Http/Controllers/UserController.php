<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use App\Mail\SendMail;

class UserController extends Controller
{
    /**
     * Manage User (Insert/Update)
     */
    public function manageUser(Request $request)
    {
        // Validate input
        $validator = Validator::make($request->all(), [
            'p_mobile' => 'required|digits:10',
            'p_email' => 'nullable|email',
            'p_user_name' => 'required|string|max:255',
        ], [
            'p_mobile.required' => 'Mobile number is required.',
            'p_mobile.digits' => 'Mobile number must be exactly 10 digits.',
            'p_email.email' => 'Invalid email format.',
            'p_user_name.required' => 'User name is required.',
        ]);

        // Return validation errors if any
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed!',
                'errors' => $validator->errors()
            ], 422);
        }

        $action = $request->input('p_action');
        $userId = $request->input('p_user_id', 0);
        $message = '';

        try {
            // Call the stored procedure
            $result = DB::select('CALL manage_user(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, @message, ?, ?, ?, ?)', [
                $action,
                $userId,
                $request->input('p_user_name'),
                $request->input('p_email'),
                $request->input('p_mobile'),
                $request->input('p_profile_pic'),
                $request->input('p_status'),
                $request->input('p_token'),
                $request->input('p_otp'),
                $request->input('p_is_verified'),
                $request->input('p_is_available'),
                $request->input('P_pannumber'),
                $request->input('p_DocPath'),
                $request->input('p_role_abbreviation'),
                $request->input('p_ClientId'),
            ]);

            // Fetch stored procedure message
            $messageResult = DB::select('SELECT @message as message');
            $message = $messageResult[0]->message ?? 'Operation completed successfully.';

            // Send email notification if email is provided
            if (!empty($request->input('p_email'))) {
                $emailData = [
                    'name' => $request->input('p_user_name'),
                    'subject' => 'User Account Notification',
                    'message' => 'Dear ' . $request->input('p_user_name') . ', your account has been ' . 
                        ($action === 'I' ? 'created' : 'updated') . ' successfully.',
                ];

                Mail::to($request->input('p_email'))->send(new SendMail($emailData));
            }

            return response()->json([
                'status' => 'success',
                'message' => $message,
                'data' => $result
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Database error!',
                'error_details' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update User
     */
    public function updateUser(Request $request)
    {
        $userId = $request->input('p_user_id');
        if (!$userId) {
            return response()->json([
                'status' => 'error',
                'message' => 'User ID is required for update'
            ], 400);
        }

        $message = '';

        try {
            $result = DB::select('CALL manage_user(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, @message, ?, ?, ?, ?)', [
                'U', // Update action
                $userId,
                $request->input('p_user_name'),
                $request->input('p_email'),
                $request->input('p_mobile'),
                $request->input('p_profile_pic'),
                $request->input('p_status'),
                $request->input('p_token'),
                $request->input('p_otp'),
                $request->input('p_is_verified'),
                $request->input('p_is_available'),
                $request->input('P_pannumber'),
                $request->input('p_DocPath'),
                $request->input('p_role_abbreviation'),
                $request->input('p_ClientId'),
            ]);

            // Fetch stored procedure message
            $messageResult = DB::select('SELECT @message as message');
            $message = $messageResult[0]->message ?? 'User updated successfully.';

            return response()->json([
                'status' => 'success',
                'message' => $message,
                'data' => $result
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Database error!',
                'error_details' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Delete User
     */
    public function deleteUser(Request $request)
    {
        $userId = $request->input('p_user_id');

        if (!$userId) {
            return response()->json([
                'status' => 'error',
                'message' => 'User ID is required for deletion'
            ], 400);
        }

        try {
            DB::statement('CALL manage_user(?, ?, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @message, NULL, NULL, NULL, NULL)', [
                'D', // Delete action
                $userId
            ]);

            // Fetch stored procedure message
            $messageResult = DB::select('SELECT @message as message');
            $message = $messageResult[0]->message ?? 'User deleted successfully.';

            return response()->json([
                'status' => 'success',
                'message' => $message
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Database error during deletion!',
                'error_details' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get User
     */
    
//     public function getUser(Request $request)
// {
//     try {
//         $userId = $request->query('p_user_id');
//         $email = $request->query('p_email');
//         $mobile = $request->query('p_mobile');
//         $panNumber = $request->query('p_PANNumber');

//         // Ensure NULL is passed for missing parameters
//         $results = DB::select('CALL manage_user(?, ?, ?, ?, ?, NULL, NULL, NULL, NULL, NULL, NULL, @message, NULL, NULL, NULL, NULL)', [
//             'G', // Action for GET
//             $userId ?: NULL,
//             $email ?: NULL,
//             $mobile ?: NULL,
//             $panNumber ?: NULL
//         ]);

//         // Fetch the output message
//         $messageResult = DB::select("SELECT @message AS message");
//         $message = $messageResult[0]->message ?? 'Something went wrong!';

//         // ✅ NEW: Check if no user is found
//         if (empty($results)) {
//             return response()->json([
//                 'status' => 'error',
//                 'message' => 'User not found!',
//             ], 404);
//         }

//         return response()->json([
//             'status' => 'success',
//             'message' => $message,
//             'data' => $results
//         ]);

//     } catch (\Exception $e) {
//         return response()->json([
//             'status' => 'error',
//             'message' => 'Something went wrong!',
//             'error_details' => $e->getMessage()
//         ], 500);
//     }
// }

public function getUser(Request $request)
{
    try {
        $userId = $request->query('p_user_id');
        $email = $request->query('p_email');
        $mobile = $request->query('p_mobile');
        $panNumber = $request->query('p_PANNumber');
        $clientId = $request->query('p_ClientId'); // ✅ Added Client ID

        // Ensure NULL is passed for missing parameters
        $results = DB::select('CALL manage_user(?, ?, ?, ?, ?, NULL, NULL, NULL, NULL, NULL, NULL, @message, NULL, NULL, NULL, ?)', [
            'G', // Action for GET
            $userId ?: NULL,
            $email ?: NULL,
            $mobile ?: NULL,
            $panNumber ?: NULL,
            $clientId ?: NULL // ✅ Passed Client ID to the stored procedure
        ]);

        // Fetch the output message
        $messageResult = DB::select("SELECT @message AS message");
        $message = $messageResult[0]->message ?? 'Something went wrong!';

        // ✅ Check if no user is found
        if (empty($results)) {
            // Check if the issue is with Client ID
            if ($clientId) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Client ID not found!',
                ], 404);
            }
            return response()->json([
                'status' => 'error',
                'message' => 'User not found!',
            ], 404);
        }

        return response()->json([
            'status' => 'success',
            'message' => $message,
            'data' => $results
        ]);

    } catch (\Exception $e) {
        return response()->json([
            'status' => 'error',
            'message' => 'Something went wrong!',
            'error_details' => $e->getMessage()
        ], 500);
    }
}



}
