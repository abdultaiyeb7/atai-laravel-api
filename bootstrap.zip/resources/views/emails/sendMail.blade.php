<!DOCTYPE html>
<html>
<head>
    <title>{{ $data['subject'] }}</title>
</head>
<body>
    <h3>Hello, {{ $data['name'] }}</h3>
    <p>{{ $data['message'] }}</p>
    <p>Thank you for using our service.</p>
</body>
</html>
